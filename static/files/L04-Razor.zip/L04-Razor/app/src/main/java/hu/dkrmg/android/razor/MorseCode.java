package hu.dkrmg.android.razor;

import android.util.Log;

import java.util.ArrayList;

/**
 * Ez az osztály szövegek morze jellé alakításáért felelős
 *
 * @author Ákos Pap, Gyuri Dénes
 */
public class MorseCode {
    
    // ----------  Itt határozzuk meg a leütések és a szünetek hosszát -------------
    // Ezek az értékek nem változnak, ezért nyugodtan használhatjuk a "final" előtagot
    // (Pascal konstansok)
    // Az értékeket az egység leütéshez képest határoztuk meg.

    // egy időegység hossza (ms). Az összes többi érték ennek a többszöröse
    private static final long EGYSEG = 100;

    // rövid jelzés 1 időegység
    private static final long S = EGYSEG;

    // hosszú jelzés 3 időegység
    private static final long L = EGYSEG * 3;

    // Két leütés között rövid szünet (1 egység)
    private static final long LEUTESEK_KOZOTTI_SZUNET = EGYSEG;

    // Két betű közötti szünet hosszabb (3 egység)
    private static final long BETUK_KOZOTTI_SZUNET = EGYSEG * 3;

    // Két szó közötti szünet (7 egység)
    private static final long SZAVAK_KOZOTTI_SZUNET = EGYSEG * 7;



    // ----------  Az ABC -------------
    // milyen betűk/számok érdekelnek minket?
    private static long[][] morseABC = {
            {S, L},         // A
            {L, S, S, S},   // B
            {L, S, L, S},   // C
            {L, S, S},      // D
            {S},            // E
            {S, S, L, S},   // F
            {L, L, S},      // G
            {S, S, S, S},   // H
            {S, S},         // I
            {S, L, L, L},   // J
            {L, S, L},      // K
            {S, L, S, S},   // L
            {L, L},         // M
            {L, S},         // N
            {L, L, L},      // O
            {S, L, L, S},   // P
            {L, L, S, L},   // Q
            {S, L, S},      // R
            {S, S, S},      // S
            {L},            // T
            {S, S, L},      // U
            {S, S, S, L},   // V
            {S, L, L},      // W
            {L, S, S, L},   // X
            {L, S, L, L},   // Y
            {L, L, S, S}    // Z
    };

    /**
     * Karaktersorozatot alakít át Morse-jelekké, a {@link android.os.Vibrator#vibrate(long[], int)}
     * által értelmezhető formátumra.
     *
     * @param message Az átalakítandó szöveg.
     * @return A Morse-jelek sorozata, megfelelő szünetekkel kiegészítve.
     */
    public static long[] encode(String message) {
        message = message.toLowerCase();

        ArrayList<Long> encoded = new ArrayList<Long>();
        encoded.add(0l); // first value is the initial delay.

        for (int i = 0; i < message.length(); i++) {
            char c = message.charAt(i);

            if (c >= 'a' && c <= 'z') {
                long[] code = morseABC[c - 'a'];
                for (int j = 0; j < code.length; j++) {
                    encoded.add(code[j]);
                    encoded.add(LEUTESEK_KOZOTTI_SZUNET);
                }
                encoded.set(encoded.size() - 1, BETUK_KOZOTTI_SZUNET);
            } else if (c == ' ') {
                encoded.set(encoded.size() - 1, SZAVAK_KOZOTTI_SZUNET);
            } else {
                Log.w("MorseEncoder", "Can't encode character: " + c);
            }
        }

        long[] ret = new long[encoded.size()];
        for (int i = 0; i < ret.length; i++) {
            ret[i] = encoded.get(i);
        }

        return ret;
    }
}
