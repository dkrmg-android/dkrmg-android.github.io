package hu.dkrmg.android.razor;

import android.app.Activity;
import android.os.Bundle;


public class MainActivity extends Activity {

    // TODO 1.4a A rezgőmotor változójának deklarációja

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // TODO 1.4b A rezgőmotor változójának értékadása

        // TODO 4.1 Ide jöjjön a naplózó utasítás!
    }

    // TODO 1.2 Ide jön a rezegjOnClick függvény.

    // TODO 3.1 onPause helye

    // TODO 3.2 onResume helye

    // TODO 5.1 onStart és a maradékok helye helye

}
