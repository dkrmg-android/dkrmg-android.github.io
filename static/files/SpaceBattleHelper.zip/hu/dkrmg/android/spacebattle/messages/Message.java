package hu.dkrmg.android.spacebattle.messages;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class Message {

    public static final String TAG = "Message";
    public static final String KEY_TYPE = "type";

    public Message(Type type) {
        this.type = type;
    }

    public final String toJsonString() {

        try {
            JSONObject root = new JSONObject();
            pack(root);
            return root.toString();
        } catch (JSONException e) {
            Log.e(TAG, "Can't serialize JSON object!", e);
        }

        return null;
    }

    protected Type type;

    protected void pack(JSONObject into) throws JSONException {
        into.put(KEY_TYPE, type.toString());
    }

    public static enum Type {
        ACCELERATE("accelerate"),
        TURN("turn"),
        FIRE("fire"),
        PLAYER_INFO("playerInfo"),
        ABSOLUTE_TURN("absoluteTurn");


        private String value;

        Type(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return value;
        }
    }
}
