package hu.dkrmg.android.spacebattle.messages;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class AmountMessage extends Message {

    public static final String TAG = "AmountMessage";
    public static final String KEY_AMOUNT = "amount";

    public AmountMessage(Type type, double amount) {
        super(type);
        this.amount = amount;
    }

    protected Double amount;

    @Override
    protected void pack(JSONObject into) throws JSONException {
        super.pack(into);
        into.put(KEY_AMOUNT, amount);
    }
}
