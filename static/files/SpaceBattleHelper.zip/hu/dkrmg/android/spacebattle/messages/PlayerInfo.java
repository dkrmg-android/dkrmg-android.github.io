package hu.dkrmg.android.spacebattle.messages;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class PlayerInfo {

    public static final String TAG = "PlayerInfo";
    public static final String KEY_NAME = "name";
    public static final String KEY_COLOR = "colour"; // Warning! Not color!
    public static final String KEY_TEAM = "team";

    public static PlayerInfo fromJsonString(String json) {
        JSONObject root = null;
        try {
            root = new JSONObject(json);
        } catch (JSONException e) {
            Log.e(TAG, "Can't parse message!", e);
        }

        if (root == null) return null;

        PlayerInfo ret = new PlayerInfo();
        try {
            long col = root.getLong(KEY_COLOR);
            int a = (int) ( (col >> 24) & 0xff);
            int r = (int) ( (col >> 16) & 0xff);
            int g = (int) ( (col >> 8) & 0xff);
            int b = (int) ( (col) & 0xff);

            ret.color = a << 24 | r << 16 | g << 8 | b;


            ret.team = root.getInt(KEY_TEAM);
            ret.name = root.getString(KEY_NAME);
        } catch (JSONException e) {
            Log.e(TAG, "Field not found, or wrong type!", e);
        }

        return ret;
    }

    protected int color;
    protected String name;
    protected  int team;


    public int getColor() {
        return color;
    }
    public String getName() {
        return name;
    }
    public int getTeam() { return team; }
}
