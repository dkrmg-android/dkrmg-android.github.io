package hu.dkrmg.android.spacebattle.messages;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public interface MessageListener {

    void onInfoMessage(PlayerInfo info);

    void onConnected(Communicator communicator);

    void onDisconnected();

    void onError(String errorMessage);
}
