package hu.dkrmg.android.spacebattle.messages;

import java.io.IOException;


public class UrhajoProxy implements  MessageListener{
    private String serverHost;

    Communicator communicator;
    UrhajoListener listener;

    private static UrhajoProxy instance = null;

    private UrhajoProxy(String host, UrhajoListener listener) throws IOException {
        serverHost = host;
        Communicator.connect(host, this);
        this.listener = listener;
    }


    public static UrhajoProxy getUrhajoProxy(String host, UrhajoListener listener)
    {
        if (instance != null)
        {
            if (instance.serverHost.equals(host) && instance.listener == listener){
                return instance;
            }
            else
            {
                instance.closeConnection();
                instance = null;
            }
        }

        try {
            instance = new UrhajoProxy(host, listener);
            return instance;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;

    }

    public void closeConnection() {
        if (communicator == null)
        {
            return;
        }
        communicator.terminate();
    }

    public void turn(int angle) {
        communicator.send(new TurnMessage(Math.toRadians(angle)));
    }

    public void fire(){
        communicator.send(new FireMessage());
    }

    public void accelerate() {
        communicator.send(new AccelerateMessage(1));
    }

    public void changePlayerSettings(String name, int colour, int team) {
        communicator.send(new SetPlayerInfoMessage(name, colour, team));
    }

    public void setTurn(double x, double y)
    {
        communicator.send(new AbsoluteTurn(x,y));
    }

    @Override
    public void onInfoMessage(final PlayerInfo info) {
        if (listener != null) {
            listener.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    listener.onPlayerInfoMessage(info);
                }
            });
        }
    }

    @Override
    public void onConnected(Communicator communicator) {
        this.communicator = communicator;
    }

    @Override
    public void onDisconnected() {

    }

    @Override
    public void onError(String errorMessage) {

    }
}
