package hu.dkrmg.android.spacebattle.messages;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class FireMessage extends Message {

    public FireMessage() {
        super(Type.FIRE);
    }
}
