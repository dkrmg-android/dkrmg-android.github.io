package hu.dkrmg.android.spacebattle.messages;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class AccelerateMessage extends AmountMessage {

    public AccelerateMessage(double amount) {
        super(Type.ACCELERATE, amount);
    }
}
