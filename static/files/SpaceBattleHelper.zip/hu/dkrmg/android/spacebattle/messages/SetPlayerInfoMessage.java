package hu.dkrmg.android.spacebattle.messages;

import android.graphics.Color;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class SetPlayerInfoMessage extends Message {

    public static final String TAG = "PlayerInfoMessage";
    public static final String KEY_NAME = "name";
    public static final String KEY_COLOR = "colour"; // Warning! Not color!
    public static final String KEY_TEAM = "team";

    public SetPlayerInfoMessage(Type type) {
        super(type);
    }

    protected String name;
    protected int color;
    protected  int team;

    @Override
    protected void pack(JSONObject into) throws JSONException {
        super.pack(into);
        into.put(KEY_NAME, name);

        long col = ((long)(Color.alpha(color) )) << 24 | ((long)(Color.red(color) )) << 16 | ((long)(Color.green(color) )) << 8 | ((long)(Color.blue(color) ));
        into.put(KEY_COLOR, col);

        into.put(KEY_TEAM, team);
    }

    public SetPlayerInfoMessage(String name, int colour, int team)
    {
        super(Type.PLAYER_INFO);
        this.name = name;
        this.color = colour;
        this.team = team;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getTeam() { return team;}
    public void setTeam() { this.team = team;}
}
