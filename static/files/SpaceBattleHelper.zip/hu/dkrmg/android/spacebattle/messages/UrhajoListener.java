package hu.dkrmg.android.spacebattle.messages;

public interface UrhajoListener {

    // Implemented by an Activity, required to allow multithreading.
    void runOnUiThread(Runnable action);

    void onPlayerInfoMessage(PlayerInfo info);
}
