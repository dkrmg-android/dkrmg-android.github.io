package hu.dkrmg.android.spacebattle.messages;

/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class AbsoluteTurn extends  AmountMessage{
        public AbsoluteTurn(double amount) {
            super(Type.ABSOLUTE_TURN, amount);
        }
        public AbsoluteTurn(double x, double y)  {
            super(Type.ABSOLUTE_TURN, 0);

            // calculate angle
            double a = Math.asin(x);
            double b = Math.acos(y);

            double angle = Math.atan2(x,y);
            amount = angle;
        }
}