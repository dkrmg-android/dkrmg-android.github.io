package hu.dkrmg.android.spacebattle.messages;

import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;


/**
 * Created on 2014.12.11..
 *
 * @author Ákos Pap
 */
public class Communicator extends Thread {

    public static final String TAG = "Communicator";
    public static final int SERVER_PORT = 6000;

    public static void connect(final String host, final MessageListener listener) {

        Runnable task = new Runnable() {
            @Override
            public void run() {
                try {
                    runOnConnected(listener, new Communicator(host, listener));
                } catch (IOException e) {
                    Log.e(TAG, "Can't connect to server!", e);
                    runOnError(listener, "Couldn't connect to server!");
                }

            }
        };

        new Thread(task).start();

    }

    public void send(Message message) {
        new AsyncMessageSender(message).execute();
    }

    public void terminate() {
        this.terminated = true;
        try {
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected Communicator(String host, MessageListener listener) throws IOException {
        this.host = host;
        this.listener = listener;

        this.socket = new Socket(host, SERVER_PORT);
        this.inStream = socket.getInputStream();
        this.outStream = socket.getOutputStream();

        this.start();
    }

    protected static void runOnConnected(final MessageListener listener, final Communicator communicator) {
        listener.onConnected(communicator);
    }

    protected static void runOnDisconnected(final MessageListener listener) {
        if (listener != null) {
            listener.onDisconnected();
        }
    }

    protected static void runOnInfoMessage(final MessageListener listener, final PlayerInfo info) {
        if (listener != null) {
            listener.onInfoMessage(info);
        }
    }

    protected static void runOnError(final MessageListener listener, final String errorMessage) {
        if (listener != null) {
            listener.onError(errorMessage);
        }
    }

    @Override
    public void run() {
        try {
            while (! terminated) {
                String message = readSocket();

                if (TextUtils.isEmpty(message)) {
                    terminate();
                    continue;
                }

                PlayerInfo info = PlayerInfo.fromJsonString(message);

                if (info != null) {
                    runOnInfoMessage(listener, info);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                Log.wtf(TAG, "Can't close socket", e);
            }
            runOnDisconnected(listener);
        }
    }

    private String readSocket() throws IOException {
        int c;

        StringBuilder sb = new StringBuilder();
        while ((c = inStream.read()) != -1) {
            if (c != '#') {
                sb.append((char) c);
            } else {
                break;
            }
        }

        return sb.toString();
    }

    protected final String host;
    protected final Socket socket;
    protected final InputStream inStream;
    protected final OutputStream outStream;

    protected final MessageListener listener;

    private volatile boolean terminated = false;

    protected class AsyncMessageSender extends AsyncTask<Void, Void, Void> {

        final Message message;

        public AsyncMessageSender(Message message) {
            this.message = message;
        }


        @Override
        protected Void doInBackground(Void... params) {

            String json = message.toJsonString();
            Log.d(TAG, json);

            try {
                outStream.write(json.getBytes());
                outStream.write('#');
                outStream.flush();
            } catch (IOException e) {
                Log.e(TAG, "Can't send message!", e);
            }

            return null;
        }
    }

}
