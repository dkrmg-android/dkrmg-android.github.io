package hu.dkrmg.android.compass;

import android.app.Activity;
import android.os.Bundle;


public class IranytuActivity extends Activity {

    // TODO Komponensek változóinak deklarálása

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iranytu);

        // TODO Komponensek változóinak értékadása
    }

    // TODO onSensorChanged és onAccuracyChanged függvények

    // TODO onResume és onPause függvények

}
