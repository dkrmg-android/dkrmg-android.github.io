package hu.dkrmg.android.sensorintro;

import android.app.Activity;
import android.os.Bundle;

// TODO 1.1. A nyíllal jelölt helyre kell beszúrni!
//                      ------------------⤋
public class KozelsegActivity extends Activity {

    // Itt deklaráljuk a sensorManager-t, hogy az egész alkalmazásban elérhető legyen.
    // TODO 2.1a SensorManager deklarálása

    // TODO 3.2a Itt deklaráld a kijelzo azonosítójú komponenshez tartozó változót!

    /**
     * Emlékeztető: Ez a függvény akkor fut le, amikor elindul az alkalmazás.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // a következő két sor kötelező elem, majd később foglalkozunk vele.
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kozelseg);

        // Itt kérjük el a rendszertől a sensorManager-t.
        // TODO 2.1b SensorManager elkérése

        // TODO 3.2b Itt keresd meg, és mentsd el a változóba a kijelzo komponenst!
    }

    // TODO 2.2. Az onResume függvény helye.

    // TODO 4 Az onPause függvény helye.

    // TODO 1.2. A szenzoradatok kapcsolódási pontja(i).
}
