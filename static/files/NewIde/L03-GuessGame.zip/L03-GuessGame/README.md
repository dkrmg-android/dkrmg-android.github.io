L03-GuessGame
=============

3\. lecke: kitalálós játék


Ebben a leckében a klasszikus számkitalálós játékot fogjuk megírni.
