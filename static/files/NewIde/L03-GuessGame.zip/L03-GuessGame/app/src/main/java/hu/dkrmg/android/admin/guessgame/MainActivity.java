package hu.dkrmg.android.admin.guessgame;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;


public class MainActivity extends Activity {

    private int number;
    private Random randomGenerator;


    // Változó deklaráció. Innen még hiányzik pár!
    TextView leiras;
    // TODO 2.1.a: Ide kell, hogy jöjjön egy Button típusú változó. A neve legyen: gomb1

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Ez itt nem számít egyelőre
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Véletlenszám generátor létrehozása.
        randomGenerator = new Random();


        // Komponensek megkeresése
        leiras = (TextView) findViewById(R.id.leiras);
        // TODO 2.1.b: a gomb megkeresése, majd a gomb1 változóhoz hozzárendelése
    }

    // TODO 1: Ide írd be, hogy mi történjen a gomb lenyomásakor!

    /**
     * A "Tippelek!" gomb eseménykezelője.
     * Beolvassa a tippet, számot csinál belőle, megnézi, hogy a
     * gondolt számhoz képest mekkora, és kiír egy segítséget.
     * Végül törli a tipp szövegdobozt.
     */
    public void pickButtonClicked(View v) {
        // A tipp beolvasása a szövegdobozból.
        // A szövegdoboz nem tudja, hogy a felhasználó számot írt be,
        // mindenképp szövegként adja vissza a tartalmát.
        // Ahhoz, hogy a gondolt számot össze tudjuk hasonlítani a tippel,
        // a tippet előbb számmá kell konvertálni.
        // TODO 4.1 szöveg kiolvasása a tipp szövegmezőből, majd számmál alakítás/konvertálás

        // A tipp összehasonlítása a gondolt számmal, és az eredmény kijelzése.
        // TODO 4.2: Tipp ellenőrzése, szöveg+szín beállítása az eredmánynek megfelelően.

        // Tipp szövegdoboz törlése
        // TODO 4.3: Előző tipp törlése a szövegdobozból.
    }

    /**
     * Az "Újrakezdés" gomb eseménykezelője.
     */
    public void resetButtonClicked(View v) {
        // Egy új véletlen szám kérése a generátortól
        number = randomGenerator.nextInt(100) + 1;

        // Korábbi eredmény törlése
        // TODO 4.4: Eredményjelző szöveg törlése

        // Értesítés megjelenítése
        // TODO 4.5: Játékos értesítése, hogy kezdőthet a játék (Toast).
    }
}
