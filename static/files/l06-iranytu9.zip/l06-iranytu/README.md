# README #

This is the project for L06, rotating an image based on the compass orientation.